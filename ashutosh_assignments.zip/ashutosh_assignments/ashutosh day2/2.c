#include<stdio.h>
int main()
{
int i = 10,j= 5;

printf("bitwise AND %d:\n", i&j );
printf("bitwise OR %d:\n", i|j );
printf("bitwise Ex-OR %d:\n", i^j );
printf("bitwise left shift %d:\n", i<<2 );
printf("bitwise SHift right %d:\n", j>>2 );

}
