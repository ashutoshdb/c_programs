#include<stdio.h>
int main()
{
int r;
float p;

printf("Enter the radius");
scanf("%d",&r);

p = 2*3.14*r;

printf("Perimeter: %fs \n",p);
}
