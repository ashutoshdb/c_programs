#include<stdio.h>
int main()
{
int z,k,a,b,e;
int  i= 8, j = 5; 
float  x = 0.005,  y = 0.01; 
char c = c, d = d; 

z = (3*i*j)%(2*d);
k =(i*j)%(c+2*d) / (x*y);
a =5 * (i + j) > c ;
b = 2*x+ (y== 0);
e = (x > y) && (i > 0) || (j < 5);
 
printf("value is %d \n, %d\n, %d\n, %d\n, %d\n", z,k,a,b,e);
}

