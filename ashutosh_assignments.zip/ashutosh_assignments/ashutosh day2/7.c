#include<stdio.h>
int main()
{
float p,t,r, i;
printf("Enter value of p");
scanf("%f",&p);
printf("Enter value of t");
scanf("%f",&t);
printf("Enter value of r");
scanf("%f",&r);


i = (p*t*r)/100;

printf("interest: %f \n", i);
}
