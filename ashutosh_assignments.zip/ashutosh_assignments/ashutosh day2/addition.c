#include<stdio.h>
int main()
{
int i,j,k;
printf("enter the number:");
scanf("%d", &i);

printf("enter the number:");
scanf("%d", &j);

k = i+j;

printf("value of z is :%d \n", k);
}
