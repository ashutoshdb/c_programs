#include<stdio.h>
int main()
{
int i,j,k;
printf("enter the number:");
scanf("%d", &i);

printf("enter the number:");
scanf("%d", &j);

if(i>j)
	printf("i is greater than j \n");
else
	printf("j is greter than i \n");
	
}

