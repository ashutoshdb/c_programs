#include<stdio.h>
int main()
{
int i,j;

printf("Enter the value of first number: ");
scanf("%d",&i);
printf("Enter the value of second number: ");
scanf("%d",&j);

printf("sum of both the numbers:,%d \n", i+j);
printf("subtraction of both the numbers: %d \n:",i-j);
printf("multiplication of both the numbers: %d\n", i*j);
printf("division of both the numbers: %d\n", i/j);
printf("module of both the numbers:%d \n", i%j);

}
