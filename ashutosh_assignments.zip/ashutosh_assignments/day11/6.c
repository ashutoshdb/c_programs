#include <stdio.h>

int main() {
int area;
const int r = 10   ;
const float pi = 3.14;
const char nl='\n';

   area = 2*pi*r;
   printf("area : %d", area);
   printf("%c", nl);

   return 0;
}
