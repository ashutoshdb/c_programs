#include<stdio.h>
int main()
{
int i,s,t,sum=0;


printf("Enter two values");
scanf("%d,%d",&s,&t);
for(i=s;i<=t;i++){
	sum = sum+i;
	
} 

printf("sum:%d",sum);


}
